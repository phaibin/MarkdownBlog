</div>
<!--/wrapper -->

<div id="footer">
	<p class="copyright">&copy; <a href="<?php echo get_option('home'); ?>"><?php bloginfo('name'); ?></a> <?php echo date('Y') ?></p>
	<p class="credits"><a href="http://icondock.com">Icons</a> &amp; <a href="http://www.ndesign-studio.com/wp-themes"><?php _e('Wordpress Theme','notepad-theme'); ?></a> <?php _e('by','notepad-theme'); ?> <?php _e('<a href="http://www.ndesign-studio.com">N.Design</a>','notepad-theme'); ?></p>
</div>
<!--/footer -->

</div>
<!--/pagewrapper -->

<?php wp_footer(); ?>
</body>
</html>
