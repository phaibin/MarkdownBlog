//
//  NSImage+NSImage_Categories.h
//  QWeiboClient
//
//  Created by Leon on 10/18/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface NSImage (Categories)

- (void)fixSize;

@end
